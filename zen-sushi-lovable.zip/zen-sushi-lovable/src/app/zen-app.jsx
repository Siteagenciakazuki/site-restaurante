/* ZEN SUSHI — app combinado (components + páginas + router) num único
   módulo, preservando o escopo compartilhado do código original.
   Globais (React, ReactDOM, KZ_DATA, KZ_SEO, design system) são
   carregados antes em src/main.jsx. */

/* ===================== components ===================== */
/* ZEN SUSHI — shared layout + UI components. Exports to window. */
const { useState, useEffect, useRef } = React;
const KZ = window.KAZUKIDesignSystem_63706c;
const { Button, Badge, Card, Eyebrow, KatanaDivider, SocialBar, Crest } = KZ;
const R = window.KZ_DATA.RESTAURANT;
const SEO = window.KZ_SEO;

/* ---------- Barra social ZEN SUSHI: ícones de marca corretos + links ---------- */
const SOCIAL_GLYPHS = {
  instagram: "M12 2.16c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.22.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.42.36 1.05.41 2.22.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.22-.22.56-.48.96-.9 1.38-.42.42-.82.68-1.38.9-.42.16-1.05.36-2.22.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.22-.41a3.73 3.73 0 0 1-1.38-.9 3.73 3.73 0 0 1-.9-1.38c-.16-.42-.36-1.05-.41-2.22C2.17 15.58 2.16 15.2 2.16 12s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.22.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.42-.16 1.05-.36 2.22-.41C8.42 2.17 8.8 2.16 12 2.16Zm0 1.62c-3.15 0-3.52.01-4.76.07-1.15.05-1.77.24-2.19.4-.55.22-.94.47-1.35.88-.41.41-.66.8-.88 1.35-.16.42-.35 1.04-.4 2.19-.06 1.24-.07 1.61-.07 4.76s.01 3.52.07 4.76c.05 1.15.24 1.77.4 2.19.22.55.47.94.88 1.35.41.41.8.66 1.35.88.42.16 1.04.35 2.19.4 1.24.06 1.61.07 4.76.07s3.52-.01 4.76-.07c1.15-.05 1.77-.24 2.19-.4.55-.22.94-.47 1.35-.88.41-.41.66-.8.88-1.35.16-.42.35-1.04.4-2.19.06-1.24.07-1.61.07-4.76s-.01-3.52-.07-4.76c-.05-1.15-.24-1.77-.4-2.19a3.6 3.6 0 0 0-.88-1.35 3.6 3.6 0 0 0-1.35-.88c-.42-.16-1.04-.35-2.19-.4-1.24-.06-1.61-.07-4.76-.07Zm0 2.76a5.46 5.46 0 1 1 0 10.92 5.46 5.46 0 0 1 0-10.92Zm0 9a3.54 3.54 0 1 0 0-7.08 3.54 3.54 0 0 0 0 7.08Zm6.95-9.22a1.28 1.28 0 1 1-2.56 0 1.28 1.28 0 0 1 2.56 0Z",
  facebook: "M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07c0 6.02 4.39 11.01 10.13 11.93v-8.44H7.08v-3.49h3.05V9.41c0-3.02 1.79-4.69 4.53-4.69 1.31 0 2.69.24 2.69.24v2.97h-1.52c-1.49 0-1.96.93-1.96 1.89v2.25h3.33l-.53 3.49h-2.8V24C19.61 23.08 24 18.1 24 12.07Z",
  whatsapp: "M19.05 4.91A9.82 9.82 0 0 0 12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38a9.9 9.9 0 0 0 4.74 1.21h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.91-7.01ZM12.04 20.15h-.01a8.2 8.2 0 0 1-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.25-8.24a8.2 8.2 0 0 1 5.83 2.42 8.2 8.2 0 0 1 2.41 5.83c0 4.54-3.7 8.24-8.24 8.24Zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.13-.16.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.12-.14.16-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.4-.42-.56-.42-.14-.01-.31-.01-.48-.01-.17 0-.43.06-.66.31-.23.25-.86.85-.86 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.75 2.67 4.24 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.06-.11-.22-.17-.47-.29Z",
  tiktok: "M16.6 5.82a4.28 4.28 0 0 1-1.13-2.82h-3.1v12.4a2.45 2.45 0 1 1-2.45-2.45c.25 0 .49.04.72.11V9.9a5.6 5.6 0 0 0-.72-.05 5.55 5.55 0 1 0 5.55 5.55V9.01a7.3 7.3 0 0 0 4.27 1.37V7.28a4.28 4.28 0 0 1-3.14-1.46Z",
};
function ZenSocial({ size = 42 }) {
  const links = [
    { id: "instagram", url: R.social.instagram, label: "Instagram" },
    { id: "facebook", url: R.social.facebook, label: "Facebook" },
    { id: "whatsapp", url: "https://wa.me/" + R.whatsapp, label: "WhatsApp" },
    { id: "tiktok", url: R.social.tiktok, label: "TikTok" },
  ];
  return (
    <div className="kz-social">
      <div className="kz-social-row">
        {links.map((s) => (
          <a key={s.id} className="kz-social-chip" href={s.url} target="_blank" rel="noopener" aria-label={s.label} title={s.label} style={{ width: size, height: size }}>
            <svg width={size * 0.52} height={size * 0.52} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
              <path d={SOCIAL_GLYPHS[s.id]} />
            </svg>
          </a>
        ))}
      </div>
      <span className="kz-social-handle">{R.social.handle}</span>
    </div>
  );
}

/* ---------- ZEN SUSHI brand mark: ensō (zen brush circle) + rising-sun dot ---------- */
function BrandMark({ size = 44, withWord = false, stacked = false }) {
  const mark = (
    <svg className="kz-mark" width={size} height={size} viewBox="0 0 100 100" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="zenGold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#F6DDA0" />
          <stop offset="0.5" stopColor="#D4A853" />
          <stop offset="1" stopColor="#9C701F" />
        </linearGradient>
      </defs>
      {/* ensō — brush-stroke circle with a gap (lift of the brush) */}
      <g transform="rotate(-18 50 50)">
        <path d="M 78.5 27 A 36 36 0 1 1 60 16.2" fill="none" stroke="url(#zenGold)" strokeWidth="7.5" strokeLinecap="round" />
        {/* brush tail taper */}
        <circle cx="60" cy="16.2" r="2.2" fill="#9C701F" />
      </g>
      {/* rising sun / salmon nigiri dot in the opening */}
      <circle cx="68" cy="30" r="6.4" fill="#AF2828" />
      <circle cx="68" cy="30" r="6.4" fill="none" stroke="#F6DDA0" strokeWidth="1" opacity="0.5" />
    </svg>
  );
  if (!withWord) return mark;
  return (
    <span className={"kz-lockup" + (stacked ? " is-stacked" : "")}>
      {mark}
      <span className="kz-lockup-word">ZEN<span className="kz-lockup-word-sub">SUSHI</span></span>
    </span>
  );
}

/* ---------- Navigation ---------- */
const NAV_LINKS = [
  { to: "#/", label: "Início" },
  { to: "#/menu", label: "Cardápio" },
  { to: "#/reservas", label: "Reservas" },
  { to: "#/delivery", label: "Delivery" },
  { to: "#/localizacao", label: "Como Chegar" },
  { to: "#/blog", label: "Blog" },
];

function Nav({ route }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll);
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => { setOpen(false); }, [route]);

  const isActive = (to) =>
    to === "#/" ? route === "home" : ("#/" + route) === to;

  return (
    <header className={"kz-nav" + (scrolled ? " is-scrolled" : "")}>
      <div className="kz-nav-inner">
        <a href="#/" className="kz-brand" aria-label="ZEN SUSHI — página inicial">
          <BrandMark size={42} />
          <span className="kz-brand-word">ZEN SUSHI</span>
        </a>
        <nav className="kz-nav-links" aria-label="Navegação principal">
          {NAV_LINKS.map((l) => (
            <a key={l.to} href={l.to} className={"kz-nav-link" + (isActive(l.to) ? " is-active" : "")}>
              {l.label}
            </a>
          ))}
        </nav>
        <div className="kz-nav-cta">
          <Button variant="gold" size="sm" onClick={() => { location.hash = "#/reservas"; }}>
            Reservar
          </Button>
        </div>
        <button className="kz-burger" aria-label="Abrir menu" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
          <span /><span /><span />
        </button>
      </div>
      {open && (
        <div className="kz-mobile-menu">
          {NAV_LINKS.map((l) => (
            <a key={l.to} href={l.to} className={"kz-nav-link" + (isActive(l.to) ? " is-active" : "")}>{l.label}</a>
          ))}
          <a href="#/reservas" className="kz-nav-link kz-mobile-reserve">Reservar mesa →</a>
        </div>
      )}
    </header>
  );
}

/* ---------- Footer ---------- */
function Footer() {
  return (
    <footer className="kz-footer">
      <div className="kz-footer-grid">
        <div className="kz-footer-col">
          <BrandMark size={72} withWord stacked />
          <p className="kz-footer-tagline">{R.descricao}</p>
          <ZenSocial size={42} />
        </div>
        <div className="kz-footer-col">
          <h2 className="kz-footer-h">Visite-nos</h2>
          <address className="kz-address">
            {R.rua}<br />
            {R.bairro}, {R.cidade} - {R.estado}<br />
            CEP {R.cep}<br />
            <a href={"tel:" + R.telefoneE164}>{R.telefone}</a><br />
            <a href={"mailto:" + R.email}>{R.email}</a>
          </address>
        </div>
        <div className="kz-footer-col">
          <h2 className="kz-footer-h">Horários</h2>
          <ul className="kz-hours">
            {R.horarios.map((h) => (
              <li key={h.dias}><span>{h.dias}</span><span className="kz-hours-time">{h.abre}–{h.fecha}</span></li>
            ))}
          </ul>
        </div>
        <div className="kz-footer-col">
          <h2 className="kz-footer-h">Navegação</h2>
          <ul className="kz-footer-nav">
            {NAV_LINKS.map((l) => (<li key={l.to}><a href={l.to}>{l.label}</a></li>))}
          </ul>
        </div>
      </div>
      <KatanaDivider style={{ margin: "0 auto", maxWidth: 1200 }} />
      <p className="kz-copyright">© 2026 {R.legalName} · {R.enderecoCompleto} · Todos os direitos reservados.</p>
    </footer>
  );
}

/* ---------- Dish image placeholder ---------- */
function DishImage({ name, tall }) {
  const initial = name.trim()[0];
  return (
    <div className={"kz-dish-img" + (tall ? " is-tall" : "")} role="img" aria-label={"Foto do prato: " + name}>
      <div className="kz-dish-img-inner">
        <span className="kz-dish-initial">{initial}</span>
        <span className="kz-dish-glyph">◆</span>
      </div>
    </div>
  );
}

/* ---------- Page hero band ---------- */
function PageHero({ eyebrow, title, subtitle, children }) {
  return (
    <section className="kz-pagehero">
      <div className="kz-pagehero-inner">
        {eyebrow && <Eyebrow rule="left">{eyebrow}</Eyebrow>}
        <h1 className="kz-pagehero-title">{title}</h1>
        {subtitle && <p className="kz-pagehero-sub">{subtitle}</p>}
        {children}
      </div>
    </section>
  );
}

/* ---------- Auditor SEO panel ---------- */
function AuditorPanel({ route, tab, setTab, open, setOpen }) {
  const [events, setEvents] = useState(SEO.getEvents());
  const [, force] = useState(0);
  useEffect(() => SEO.onEvents(setEvents), []);
  // re-audit whenever route changes (after render)
  const [checks, setChecks] = useState([]);
  const [schemas, setSchemas] = useState([]);
  useEffect(() => {
    const t = setTimeout(() => {
      setChecks(SEO.auditPage("#page-root"));
      setSchemas(SEO.getSchemas());
    }, 80);
    return () => clearTimeout(t);
  }, [route]);

  const passCount = checks.filter((c) => c.pass).length;

  return (
    <>
      <button className={"kz-aud-fab" + (open ? " is-open" : "")} onClick={() => setOpen(!open)} aria-label="Auditor SEO">
        <span className="kz-aud-fab-glyph">⚙</span>
        <span className="kz-aud-fab-label">Auditor&nbsp;SEO</span>
        {checks.length > 0 && (
          <span className={"kz-aud-fab-score" + (passCount === checks.length ? " is-perfect" : "")}>{passCount}/{checks.length}</span>
        )}
      </button>

      <aside className={"kz-aud" + (open ? " is-open" : "")} aria-hidden={!open}>
        <div className="kz-aud-head">
          <div>
            <span className="kz-aud-kicker">Painel técnico</span>
            <h2 className="kz-aud-title">Auditor SEO</h2>
          </div>
          <button className="kz-aud-close" onClick={() => setOpen(false)} aria-label="Fechar">×</button>
        </div>
        <div className="kz-aud-tabs">
          {[
            ["audit", "Auditoria"],
            ["schema", "Schema"],
            ["ga4", "GA4 · " + events.length],
            ["sitemap", "Sitemap"],
          ].map(([k, label]) => (
            <button key={k} className={"kz-aud-tab" + (tab === k ? " is-active" : "")} onClick={() => setTab(k)}>{label}</button>
          ))}
        </div>

        <div className="kz-aud-body" data-lenis-prevent>
          {tab === "audit" && (
            <div>
              <p className="kz-aud-note">Verificação ao vivo do DOM da rota atual <code>/{route === "home" ? "" : route}</code>.</p>
              <ul className="kz-checklist">
                {checks.map((c, i) => (
                  <li key={i} className={c.pass ? "ok" : "fail"}>
                    <span className="kz-check-icon">{c.pass ? "✓" : "✕"}</span>
                    <span className="kz-check-body"><strong>{c.label}</strong><em>{c.detail}</em></span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          {tab === "schema" && (
            <div>
              <p className="kz-aud-note">{schemas.length} bloco(s) JSON-LD injetado(s) no <code>&lt;head&gt;</code>. Valide no <a href="https://search.google.com/test/rich-results" target="_blank" rel="noopener">Rich Results Test</a>.</p>
              {schemas.map((s, i) => (
                <details key={i} open={i === 0} className="kz-code-details">
                  <summary>{s["@type"]}</summary>
                  <pre className="kz-code">{JSON.stringify(s, null, 2)}</pre>
                </details>
              ))}
            </div>
          )}
          {tab === "ga4" && (
            <div>
              <p className="kz-aud-note">Eventos <code>gtag</code> disparados nesta sessão (ID <code>{SEO.GA4_ID}</code>). Mais recente no topo.</p>
              {events.length === 0 && <p className="kz-aud-empty">Nenhum evento ainda — navegue e interaja.</p>}
              <ul className="kz-eventlog">
                {events.map((e, i) => (
                  <li key={i}>
                    <span className="kz-event-name">{e.name}</span>
                    <span className="kz-event-time">{e.t}</span>
                    {Object.keys(e.params).length > 0 && (
                      <code className="kz-event-params">{JSON.stringify(e.params)}</code>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {tab === "sitemap" && (
            <div>
              <p className="kz-aud-note">Gerado dinamicamente a partir das rotas + posts do blog. <code>/admin</code> é excluído (noindex).</p>
              <pre className="kz-code">{SEO.buildSitemap()}</pre>
            </div>
          )}
        </div>
      </aside>
      {open && <div className="kz-aud-scrim" onClick={() => setOpen(false)} />}
    </>
  );
}

Object.assign(window, { Nav, Footer, DishImage, PageHero, AuditorPanel, NAV_LINKS, BrandMark });

/* ===================== pages: core ===================== */
/* ZEN SUSHI — core pages: Home, Menu, Reservas, Delivery. */
const { Button: B, Badge: Bd, Card: Cd, Eyebrow: Ey, KatanaDivider: KD, PriceTag, PromoSeal } = window.KAZUKIDesignSystem_63706c;
const RES = window.KZ_DATA.RESTAURANT;
const MENU = window.KZ_DATA.MENU;
const seo = window.KZ_SEO;

/* Default Japanese-food photos — drag & drop your own over any slot to replace. */
const PHOTOS = {
  hero: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1400&q=80",
  missao: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200&q=80",
  destaques: [
    "https://images.unsplash.com/photo-1600891964092-4316c288032e?w=1000&q=80",
    "https://images.unsplash.com/photo-1476124369491-e7addf5db371?w=1000&q=80",
    "https://images.unsplash.com/photo-1558030006-450675393462?w=1000&q=80",
  ],
};

/* ============ HOME ============ */
function HomePage() {
  React.useEffect(() => { seo.track("home_view", { page: "home" }); }, []);
  const cta = (label, hash) => { seo.track("cta_click", { label, destino: hash }); location.hash = hash; };

  const diferenciais = [
    { t: "Cortes nobres", d: "Picanha, bife ancho e filé mignon selecionados, finalizados na brasa." },
    { t: "Risotos artesanais", d: "Arroz arbóreo no ponto all'onda, do camarão ao porcini com trufas." },
    { t: "Carta de vinhos", d: "Seleção do sommelier para harmonizar cada prato da casa." },
    { t: "Ambiente premium", d: "A elegância do aço samurai traduzida em uma mesa contemporânea." },
  ];

  return (
    <div>
      <section className="kz-hero">
        <div className="kz-hero-bg-wrap">
          <image-slot class="kz-hero-slot" id="hero-foto" shape="rect" src={PHOTOS.hero} placeholder="Arraste uma foto do restaurante ou prato"></image-slot>
        </div>
        <div className="kz-hero-overlay" aria-hidden="true" />
        <div className="kz-hero-inner">
          <div className="kz-hero-content">
            <Ey rule="left" color="gold">Alta gastronomia · {RES.cidade} - {RES.estado}</Ey>
            <p className="kz-hero-greeting">Seja bem-vindo ao <strong>ZEN SUSHI</strong></p>
            <h1 className="kz-hero-title">Restaurante<br /><span>em Cotia</span></h1>
            <p className="kz-hero-sub">{RES.descricao}</p>
            <div className="kz-hero-actions">
              <B variant="gold" size="lg" iconRight="→" onClick={() => cta("Reservar mesa", "#/reservas")}>Reservar mesa</B>
              <B variant="outline" size="lg" onClick={() => cta("Ver cardápio", "#/menu")}>Ver cardápio</B>
              <B variant="blood" size="lg" onClick={() => cta("Pedir delivery", "#/delivery")}>Pedir delivery</B>
            </div>
          </div>
        </div>
        <div className="kz-hero-strip">
          <span>★ ★ ★ ★ ★</span><span>Reservas e delivery</span><span>Centro · Cotia</span><span>{RES.telefone}</span>
        </div>
      </section>

      <section className="kz-section kz-mission">
        <div className="kz-mission-grid">
          <div>
            <Ey rule="left">Nossa essência</Ey>
            <h2 className="kz-h2">Nossa Missão</h2>
            <p className="kz-lead">Servir alta gastronomia com a disciplina e a honra de um samurai — do primeiro corte ao último brinde.</p>
            <p className="kz-body">No ZEN SUSHI, cada prato é uma lâmina afiada: precisão na técnica, respeito ao ingrediente e uma apresentação que impõe presença. Acreditamos que comer bem em Cotia não deveria exigir uma viagem à capital — por isso trouxemos cortes nobres, frutos do mar e uma confeitaria artesanal para o coração da cidade.</p>
            <div className="kz-mission-actions">
              <B variant="ghost" iconRight="→" onClick={() => cta("Conheça o cardápio", "#/menu")}>Conheça o cardápio</B>
            </div>
          </div>
          <div className="kz-mission-figure">
            <image-slot class="kz-mission-slot" id="missao-foto" shape="rounded" radius="8" src={PHOTOS.missao} placeholder="Arraste uma foto de comida japonesa"></image-slot>
          </div>
        </div>
      </section>

      <section className="kz-section kz-diff">
        <div className="kz-section-head">
          <Ey rule="both">O que nos torna únicos</Ey>
          <h2 className="kz-h2 kz-center">Diferenciais da casa</h2>
        </div>
        <div className="kz-diff-grid">
          {diferenciais.map((d) => (
            <Cd key={d.t} pattern className="kz-diff-card">
              <h3 className="kz-h3">{d.t}</h3>
              <p className="kz-body">{d.d}</p>
            </Cd>
          ))}
        </div>
      </section>

      <section className="kz-section kz-featured">
        <div className="kz-section-head">
          <Ey rule="both" color="blood">Mais pedidos</Ey>
          <h2 className="kz-h2 kz-center">Destaques do chef</h2>
        </div>
        <div className="kz-featured-grid">
          {MENU.find((s) => s.id === "principais").itens.filter((i) => i.destaque).map((it, fi) => (
            <article key={it.nome} className="kz-feat-card">
              <image-slot class="kz-feat-slot" id={"destaque-" + fi} shape="rect" src={PHOTOS.destaques[fi]} placeholder="Arraste a foto do prato"></image-slot>
              <div className="kz-feat-body">
                <h3 className="kz-h3">{it.nome}</h3>
                <p className="kz-body">{it.desc}</p>
                <PriceTag price={it.preco} size="sm" />
              </div>
            </article>
          ))}
        </div>
        <div className="kz-center" style={{ marginTop: "var(--space-7)" }}>
          <B variant="gold" size="lg" iconRight="→" onClick={() => cta("Ver cardápio completo", "#/menu")}>Ver cardápio completo</B>
        </div>
      </section>

      <section className="kz-section kz-cta-band">
        <h2 className="kz-h2 kz-center">Pronto para uma experiência inesquecível?</h2>
        <p className="kz-lead kz-center">Reserve sua mesa ou peça em casa pelos principais aplicativos de delivery de Cotia.</p>
        <div className="kz-hero-actions kz-center-flex">
          <B variant="gold" size="lg" iconRight="→" onClick={() => cta("Reservar agora", "#/reservas")}>Reservar agora</B>
          <B variant="blood" size="lg" onClick={() => cta("Peça delivery", "#/delivery")}>Peça delivery</B>
        </div>
      </section>
    </div>
  );
}

/* Pequenos selos de dieta exibidos direto no nome do prato. */
function DietIcons({ tags }) {
  const T = window.KZ_DATA.TAGS;
  const map = {
    [T.VEGANO]: { ab: "VG", cls: "is-vegan", title: "Vegano" },
    [T.VEGETARIANO]: { ab: "V", cls: "is-veg", title: "Vegetariano" },
    [T.SEMGLUTEN]: { ab: "GF", cls: "is-gf", title: "Sem Glúten" },
    [T.PICANTE]: { ab: "🌶", cls: "is-spicy", title: "Picante" },
  };
  const shown = (tags || []).filter((t) => map[t]);
  if (!shown.length) return null;
  return (
    <span className="kz-diet" aria-label={"Dieta: " + shown.map((t) => map[t].title).join(", ")}>
      {shown.map((t) => (
        <span key={t} className={"kz-diet-dot " + map[t].cls} title={map[t].title}>{map[t].ab}</span>
      ))}
    </span>
  );
}

/* ============ MENU ============ */
function MenuPage() {
  const [active, setActive] = React.useState(MENU[0].id);
  const [expanded, setExpanded] = React.useState(null);
  const lockUntil = React.useRef(0); // ignora scroll-spy logo após um clique

  const goCat = (id) => {
    setActive(id);
    lockUntil.current = Date.now() + 900; // trava o spy durante a rolagem suave
    const sec = MENU.find((s) => s.id === id);
    seo.track("menu_category_view", { categoria: sec.nome });
    const el = document.getElementById("cat-" + id);
    if (el) {
      const top = el.getBoundingClientRect().top + window.scrollY - 120;
      if (window.__smooth) window.__smooth.to(top);
      else window.scrollTo({ top, behavior: "smooth" });
    }
  };

  // Scroll spy: ativa a categoria conforme a seção entra na área de leitura.
  React.useEffect(() => {
    const onScroll = () => {
      if (Date.now() < lockUntil.current) return;
      const line = 160; // linha de referência abaixo da navbar
      let current = MENU[0].id;
      for (const sec of MENU) {
        const el = document.getElementById("cat-" + sec.id);
        if (el && el.getBoundingClientRect().top - line <= 0) current = sec.id;
      }
      setActive((prev) => (prev === current ? prev : current));
      // mantém o chip ativo visível na barra rolável (mobile)
      const btn = document.querySelector('.kz-catnav-btn[data-cat="' + current + '"]');
      const nav = document.querySelector(".kz-catnav");
      if (btn && nav && nav.scrollWidth > nav.clientWidth) {
        const target = btn.offsetLeft - nav.clientWidth / 2 + btn.offsetWidth / 2;
        nav.scrollTo({ left: target, behavior: "smooth" });
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    if (window.lenis) window.lenis.on("scroll", onScroll);
    onScroll();
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (window.lenis && window.lenis.off) window.lenis.off("scroll", onScroll);
    };
  }, []);

  const toggleItem = (key, nome) => {
    setExpanded((e) => {
      const next = e === key ? null : key;
      if (next) seo.track("item_details_expand", { prato: nome });
      return next;
    });
  };

  return (
    <div>
      <PageHero eyebrow="Cardápio" title="Cardápio Completo" subtitle="Entradas, pratos principais, sobremesas artesanais e uma carta de bebidas selecionada. Sabores que fazem do ZEN SUSHI o melhor jantar em Cotia." />
      <div className="kz-catnav-wrap">
        <nav className="kz-catnav" aria-label="Categorias do cardápio">
          {MENU.map((s) => (
            <button key={s.id} data-cat={s.id} className={"kz-catnav-btn" + (active === s.id ? " is-active" : "")} onClick={() => goCat(s.id)}>
              {s.nome} <span className="kz-catnav-count">{s.itens.length}</span>
            </button>
          ))}
        </nav>
      </div>

      <div className="kz-diet-legend">
        <span className="kz-diet-legend-item"><span className="kz-diet-dot is-veg">V</span> Vegetariano</span>
        <span className="kz-diet-legend-item"><span className="kz-diet-dot is-vegan">VG</span> Vegano</span>
        <span className="kz-diet-legend-item"><span className="kz-diet-dot is-gf">GF</span> Sem Glúten</span>
        <span className="kz-diet-legend-item"><span className="kz-diet-dot is-spicy">🌶</span> Picante</span>
      </div>

      <div className="kz-section kz-menu-body">
        {MENU.map((sec) => (
          <section key={sec.id} id={"cat-" + sec.id} className="kz-menu-cat">
            <div className="kz-menu-cat-head">
              <Ey rule="left" color="gold">{sec.kw}</Ey>
              <h2 className="kz-h2">{sec.nome}</h2>
              <KD style={{ marginTop: "var(--space-4)" }} />
            </div>
            <ul className="kz-menu-list">
              {sec.itens.map((it, idx) => {
                const key = sec.id + "-" + idx;
                const isOpen = expanded === key;
                return (
                  <li key={key} className={"kz-menu-item" + (isOpen ? " is-open" : "")}>
                    <button className="kz-menu-item-row" onClick={() => toggleItem(key, it.nome)} aria-expanded={isOpen}>
                      <span className="kz-menu-item-main">
                        <span className="kz-menu-item-titlerow">
                          <h3 className="kz-h3 kz-menu-item-name">{it.nome}</h3>
                          <DietIcons tags={it.tags} />
                          {it.destaque && <Bd variant="blood">Mais pedido</Bd>}
                        </span>
                        <p className="kz-menu-item-desc">{it.desc}</p>
                      </span>
                      <span className="kz-menu-item-aside">
                        <span className="kz-menu-price"><i>R$</i>{it.preco}</span>
                        <span className="kz-menu-toggle" aria-hidden="true">{isOpen ? "−" : "+"}</span>
                      </span>
                    </button>
                    {isOpen && (
                      <div className="kz-menu-item-extra">
                        <h4 className="kz-h4">Informações dietéticas</h4>
                        <div className="kz-tags">
                          {(it.tags || []).map((t) => (
                            <Bd key={t} variant={t.indexOf("Sem") === 0 || t === "Vegano" || t === "Vegetariano" ? "gold" : t === "Picante" ? "blood" : "ghost"}>{t}</Bd>
                          ))}
                          {(!it.tags || !it.tags.length) && <span className="kz-body">Consulte nossa equipe sobre restrições alimentares.</span>}
                        </div>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          </section>
        ))}
      </div>
    </div>
  );
}

/* ============ RESERVAS ============ */
function ReservasPage() {
  const [form, setForm] = React.useState({ nome: "", telefone: "", data: "", hora: "19:30", pessoas: "2", obs: "" });
  const [started, setStarted] = React.useState(false);
  const [done, setDone] = React.useState(false);
  const [errors, setErrors] = React.useState({});

  const onFocusOnce = () => { if (!started) { setStarted(true); seo.track("form_start", { form: "reserva" }); } };
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const validate = () => {
    const er = {};
    if (form.nome.trim().length < 2) er.nome = "Informe seu nome.";
    if (form.telefone.replace(/\D/g, "").length < 10) er.telefone = "Telefone inválido.";
    if (!form.data) er.data = "Escolha uma data.";
    setErrors(er);
    return Object.keys(er).length === 0;
  };
  const buildMsg = () => encodeURIComponent(
    `Olá! Gostaria de reservar uma mesa no ZEN SUSHI.\n\n` +
    `Nome: ${form.nome || "—"}\n` +
    `Data: ${form.data || "—"} às ${form.hora}\n` +
    `Pessoas: ${form.pessoas}` +
    (form.obs ? `\nObservações: ${form.obs}` : "")
  );
  const openWhatsApp = (origem) => {
    seo.track("whatsapp_api_click", { origem });
    window.open(`https://wa.me/${RES.whatsapp}?text=${buildMsg()}`, "_blank", "noopener");
  };
  const submit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    seo.track("form_success", { form: "reserva", pessoas: form.pessoas });
    setDone(true);
    openWhatsApp("confirmar_reserva");
  };
  const whatsapp = () => openWhatsApp("botao_whatsapp");

  const regras = [
    "Tolerância de 15 minutos após o horário reservado.",
    "Mesas para mais de 8 pessoas mediante consulta.",
    "Reservas para o mesmo dia somente por WhatsApp.",
    "Pets são bem-vindos na área externa.",
  ];
  const horarios = ["18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00"];

  return (
    <div>
      <PageHero eyebrow="Reservas" title="Reserva de Mesa" subtitle="Garanta seu lugar no ZEN SUSHI. Preencha o formulário ou fale direto com a casa pelo WhatsApp." />
      <div className="kz-section kz-reservas-grid">
        <div className="kz-reservas-form-col">
          <h2 className="kz-h2">Como Reservar</h2>
          <p className="kz-body">Escolha a data, o horário e o número de pessoas. Confirmamos sua reserva em poucos minutos no horário de atendimento.</p>

          {done ? (
            <Cd pattern className="kz-reserva-success">
              <PromoSeal value="OK" caption="Confirmado" size={110} rotate={-6} variant="gold" style={{ marginBottom: "var(--space-4)" }} />
              <h3 className="kz-h3">Reserva enviada, {form.nome.split(" ")[0]}!</h3>
              <p className="kz-body">Abrimos o <strong>WhatsApp</strong> com os dados da sua reserva — é só enviar a mensagem para confirmarmos. Para {form.pessoas} pessoa(s) em {form.data} às {form.hora}.</p>
              <B variant="blood" iconRight="→" onClick={whatsapp} style={{ marginTop: "var(--space-4)" }}>Abrir WhatsApp novamente</B>
            </Cd>
          ) : (
            <form className="kz-form" onSubmit={submit} noValidate>
              <div className="kz-field">
                <label htmlFor="r-nome">Nome completo</label>
                <input id="r-nome" value={form.nome} onChange={set("nome")} onFocus={onFocusOnce} placeholder="Seu nome" />
                {errors.nome && <span className="kz-err">{errors.nome}</span>}
              </div>
              <div className="kz-field">
                <label htmlFor="r-tel">Telefone / WhatsApp</label>
                <input id="r-tel" value={form.telefone} onChange={set("telefone")} onFocus={onFocusOnce} placeholder="(11) 90000-0000" inputMode="tel" />
                {errors.telefone && <span className="kz-err">{errors.telefone}</span>}
              </div>
              <div className="kz-field-row">
                <div className="kz-field">
                  <label htmlFor="r-data">Data</label>
                  <input id="r-data" type="date" value={form.data} onChange={set("data")} onFocus={onFocusOnce} />
                  {errors.data && <span className="kz-err">{errors.data}</span>}
                </div>
                <div className="kz-field">
                  <label htmlFor="r-pessoas">Pessoas</label>
                  <select id="r-pessoas" value={form.pessoas} onChange={set("pessoas")} onFocus={onFocusOnce}>
                    {[1,2,3,4,5,6,7,8].map((n) => <option key={n} value={n}>{n}</option>)}
                  </select>
                </div>
              </div>
              <div className="kz-field">
                <h3 className="kz-h3 kz-field-h">Horários disponíveis</h3>
                <div className="kz-slots">
                  {horarios.map((h) => (
                    <button type="button" key={h} className={"kz-slot" + (form.hora === h ? " is-active" : "")} onClick={() => setForm((f) => ({ ...f, hora: h }))}>{h}</button>
                  ))}
                </div>
              </div>
              <div className="kz-field">
                <label htmlFor="r-obs">Observações (opcional)</label>
                <textarea id="r-obs" rows="2" value={form.obs} onChange={set("obs")} onFocus={onFocusOnce} placeholder="Aniversário, restrições alimentares, cadeira de bebê..." />
              </div>
              <div className="kz-form-actions">
                <B variant="gold" size="lg" iconRight="→" type="submit">Confirmar reserva no WhatsApp</B>
                <B variant="ghost" size="lg" type="button" onClick={whatsapp}>Reservar pelo WhatsApp</B>
              </div>
            </form>
          )}
        </div>

        <aside className="kz-reservas-aside">
          <Cd pattern>
            <h3 className="kz-h3">Regras de Reserva</h3>
            <ul className="kz-rules">
              {regras.map((r) => <li key={r}>{r}</li>)}
            </ul>
          </Cd>
          <Cd>
            <h3 className="kz-h3">Horários de funcionamento</h3>
            <ul className="kz-hours kz-hours-dark">
              {RES.horarios.map((h) => (<li key={h.dias}><span>{h.dias}</span><span className="kz-hours-time">{h.abre}–{h.fecha}</span></li>))}
            </ul>
            <KD style={{ margin: "var(--space-4) 0" }} />
            <p className="kz-body">Prefere falar com a gente? <a className="kz-inline-link" href={"tel:" + RES.telefoneE164}>{RES.telefone}</a></p>
          </Cd>
        </aside>
      </div>
    </div>
  );
}

/* ============ DELIVERY ============ */
/* Logomarcas oficiais reconstruídas como wordmarks SVG (cores e lockup de cada marca). */
function DeliveryLogo({ id }) {
  switch (id) {
    case "ifood":
      return (
        <svg viewBox="0 0 200 80" className="kz-deliv-svg" role="img" aria-label="iFood">
          <rect width="200" height="80" rx="16" fill="#EA1D2C" />
          <text x="100" y="52" textAnchor="middle" fontFamily="'Helvetica Neue',Arial,sans-serif" fontSize="38" fontWeight="700" fill="#FFFFFF" letterSpacing="-1">
            <tspan fontStyle="italic">i</tspan>Food
          </text>
          <circle cx="71" cy="24" r="4.4" fill="#FFFFFF" />
        </svg>
      );
    case "99food":
      return (
        <svg viewBox="0 0 200 80" className="kz-deliv-svg" role="img" aria-label="99Food">
          <rect width="200" height="80" rx="16" fill="#FFD400" />
          <text x="100" y="53" textAnchor="middle" fontFamily="'Helvetica Neue',Arial,sans-serif" fontSize="40" fontWeight="800" fill="#1A1A1A" letterSpacing="-1.5">
            99<tspan fontWeight="600">Food</tspan>
          </text>
        </svg>
      );
    case "keeta":
      return (
        <svg viewBox="0 0 200 80" className="kz-deliv-svg" role="img" aria-label="Keeta">
          <rect width="200" height="80" rx="16" fill="#FFB300" />
          <circle cx="42" cy="40" r="19" fill="#1A1A1A" />
          <path d="M35 33 q4 -6 9 -2 q-3 2 -2 6 q3 -1 5 1 q-5 5 -10 2 q-4 -3 -2 -7z" fill="#FFB300" />
          <circle cx="40" cy="35" r="2" fill="#FFB300" />
          <text x="118" y="53" textAnchor="middle" fontFamily="'Helvetica Neue',Arial,sans-serif" fontSize="36" fontWeight="800" fill="#1A1A1A" letterSpacing="-1">Keeta</text>
        </svg>
      );
    case "rappi":
      return (
        <svg viewBox="0 0 200 80" className="kz-deliv-svg" role="img" aria-label="Rappi">
          <rect width="200" height="80" rx="16" fill="#FF441F" />
          <text x="100" y="52" textAnchor="middle" fontFamily="'Helvetica Neue',Arial,sans-serif" fontSize="38" fontWeight="800" fill="#FFFFFF" letterSpacing="-1">Rappi</text>
          <circle cx="135" cy="22" r="3.4" fill="#FFFFFF" />
          <circle cx="149" cy="22" r="3.4" fill="#FFFFFF" />
        </svg>
      );
    default:
      return null;
  }
}

function DeliveryPage() {
  const click = (d) => { seo.track("delivery_platform_click", { plataforma: d.nome, plataforma_id: d.id }); window.open(d.url, "_blank", "noopener"); };
  const dicas = [
    "Confira o tempo estimado antes de confirmar — pratos quentes saem na hora.",
    "Peça as sobremesas junto: elas viajam bem e chegam frescas.",
    "Use cupons de primeira compra das plataformas para economizar.",
    "Em pedidos grandes, ligue para a casa e combine o melhor horário.",
  ];
  return (
    <div>
      <PageHero eyebrow="Delivery em Cotia" title="Peça Delivery" subtitle="A alta gastronomia do ZEN SUSHI na sua casa. Escolha sua plataforma favorita e receba em toda a região de Cotia." />
      <div className="kz-section">
        <div className="kz-section-head">
          <Ey rule="both">Onde pedir</Ey>
          <h2 className="kz-h2 kz-center">Plataformas</h2>
        </div>
        <div className="kz-delivery-grid">
          {RES.delivery.map((d) => (
            <article key={d.id} className="kz-delivery-card">
              <div className="kz-delivery-logo">
                <DeliveryLogo id={d.id} />
              </div>
              <h3 className="kz-h3">{d.nome}</h3>
              <p className="kz-body">{d.desc}</p>
              <B variant="blood" fullWidth iconRight="→" onClick={() => click(d)}>Pedir no {d.nome}</B>
            </article>
          ))}
        </div>

        <div className="kz-delivery-tips">
          <h4 className="kz-h4">Dicas para um pedido perfeito</h4>
          <ul className="kz-tips-list">
            {dicas.map((t) => <li key={t}>{t}</li>)}
          </ul>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { HomePage, MenuPage, ReservasPage, DeliveryPage });

/* ===================== pages: more ===================== */
/* ZEN SUSHI — Localização, Blog, BlogPost, Admin. */
const { Button: B2, Badge: Bd2, Card: Cd2, Eyebrow: Ey2, KatanaDivider: KD2, SocialBar: SB2 } = window.KAZUKIDesignSystem_63706c;
const RST = window.KZ_DATA.RESTAURANT;
const BLOGP = window.KZ_DATA.BLOG;
const seo2 = window.KZ_SEO;

/* ============ LOCALIZAÇÃO ============ */
function MapEmbed({ onInteract }) {
  const [failed, setFailed] = React.useState(false);
  // Query limpa para geocodificação precisa (sem "Sala 7"/travessão).
  const cleanQuery = "Av. Antônio Mathias de Camargo, 895, Centro, Cotia - SP, " + RST.cep;
  const query = encodeURIComponent(cleanQuery);
  const embedSrc = "https://www.google.com/maps?q=" + query + "&z=16&hl=pt-BR&output=embed";

  if (failed) {
    return (
      <a className="kz-map kz-map-fallback" href={"https://www.google.com/maps/search/?api=1&query=" + query} target="_blank" rel="noopener" onClick={onInteract} aria-label="Abrir o mapa no Google Maps">
        <div className="kz-map-grid" aria-hidden="true" />
        <div className="kz-map-pin">
          <span className="kz-map-pin-dot" />
          <span className="kz-map-pin-label">ZEN SUSHI</span>
        </div>
        <div className="kz-map-fallback-cta">
          <strong>{RST.rua}</strong>
          <span>{RST.bairro}, {RST.cidade} - {RST.estado}</span>
          <span className="kz-map-fallback-btn">Abrir no Google Maps →</span>
        </div>
      </a>
    );
  }
  return (
    <div className="kz-map" onMouseDown={onInteract}>
      <iframe
        className="kz-map-iframe"
        title="Mapa do ZEN SUSHI Restaurante em Cotia"
        src={embedSrc}
        allowFullScreen
        onError={() => setFailed(true)}
      ></iframe>
    </div>
  );
}

function LocalizacaoPage() {
  const directions = () => {
    seo2.track("directions_click", { destino: "google_maps" });
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${RST.geo.lat},${RST.geo.lng}`, "_blank", "noopener");
  };
  const mapInteract = () => seo2.track("map_interaction", { acao: "abrir_mapa" });

  return (
    <div>
      <PageHero eyebrow="Como Chegar" title="Como chegar ao Restaurante" subtitle="Estamos no Centro de Cotia, fácil de chegar de carro ou transporte público." />
      <div className="kz-section kz-loc-grid">
        <div className="kz-loc-main">
          <h2 className="kz-h2">Mapa</h2>
          <MapEmbed onInteract={mapInteract} />
          <address className="kz-loc-address">
            <strong>{RST.rua}</strong><br />
            {RST.bairro}, {RST.cidade} - {RST.estado}<br />
            CEP {RST.cep}
          </address>
          <div className="kz-loc-actions">
            <B2 variant="gold" iconRight="→" onClick={directions}>Traçar rota</B2>
            <B2 variant="ghost" onClick={() => { seo2.track("directions_click", { destino: "ligar" }); location.href = "tel:" + RST.telefoneE164; }}>Ligar: {RST.telefone}</B2>
          </div>
        </div>

        <aside className="kz-loc-aside">
          <Cd2 pattern>
            <h3 className="kz-h3">Como vir de carro</h3>
            <p className="kz-body">Acesso rápido pela Rodovia Raposo Tavares (SP-270). Saída para o Centro de Cotia, seguindo pela Av. Antônio Mathias de Camargo. A poucos minutos do Shopping Granja Vianna.</p>
          </Cd2>
          <Cd2 pattern>
            <h3 className="kz-h3">Como vir de transporte público</h3>
            <p className="kz-body">Diversas linhas municipais param no Centro de Cotia, a uma curta caminhada do restaurante. Da estação da CPTM, há ônibus e aplicativos de transporte disponíveis.</p>
          </Cd2>
          <Cd2>
            <h4 className="kz-h4">Estacionamento</h4>
            <p className="kz-body">Estacionamento conveniado nas proximidades e vagas na via. Consulte a equipe sobre o serviço de manobrista nos fins de semana.</p>
          </Cd2>
        </aside>
      </div>
    </div>
  );
}

/* ============ BLOG (listagem) ============ */
function BlogPage() {
  return (
    <div>
      <PageHero eyebrow="Blog" title="Histórias da Cozinha" subtitle="Receitas, bastidores, harmonização de vinhos e o melhor da gastronomia em Cotia." />
      <div className="kz-section kz-blog-list">
        {BLOGP.map((p, i) => (
          <article key={p.slug} className={"kz-blog-card" + (i === 0 ? " is-feature" : "")}>
            <a href={"#/blog/" + p.slug} className="kz-blog-card-link" aria-label={p.titulo}>
              <div className="kz-blog-thumb" role="img" aria-label={"Imagem do artigo: " + p.titulo} style={p.img ? { backgroundImage: "linear-gradient(180deg, rgba(10,10,10,0.05), rgba(10,10,10,0.55)), url(" + p.img + ")", backgroundSize: "cover", backgroundPosition: "center" } : undefined}>
                <span className="kz-blog-cat">{p.categoria}</span>
                {!p.img && <span className="kz-blog-glyph">◆</span>}
              </div>
              <div className="kz-blog-card-body">
                <span className="kz-blog-meta">{p.dataLabel} · {p.leitura} de leitura</span>
                <h2 className="kz-h3 kz-blog-card-title">{p.titulo}</h2>
                <p className="kz-body">{p.resumo}</p>
                <span className="kz-blog-readmore">Ler artigo →</span>
              </div>
            </a>
          </article>
        ))}
      </div>
    </div>
  );
}

/* ============ BLOG POST ============ */
function BlogPostPage({ post }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    seo2.track("article_read", { artigo: post.slug });
    let fired = false;
    const onScroll = () => {
      const el = ref.current;
      if (!el || fired) return;
      const total = el.offsetTop + el.offsetHeight - window.innerHeight;
      const pct = total > 0 ? window.scrollY / total : 1;
      if (pct >= 0.75) { fired = true; seo2.track("scroll_depth_75", { artigo: post.slug }); }
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, [post.slug]);

  const related = BLOGP.filter((p) => p.slug !== post.slug).slice(0, 2);

  return (
    <article className="kz-post" ref={ref}>
      <div className="kz-post-hero">
        <a href="#/blog" className="kz-post-back">← Voltar ao blog</a>
        <Bd2 variant="gold">{post.categoria}</Bd2>
        <h1 className="kz-post-title">{post.titulo}</h1>
        <p className="kz-post-byline">Por {post.autor} · {post.dataLabel} · {post.leitura} de leitura</p>
      </div>
      <div className="kz-post-cover" role="img" aria-label={"Imagem de capa: " + post.titulo} style={post.img ? { backgroundImage: "linear-gradient(180deg, rgba(10,10,10,0.1), rgba(10,10,10,0.5)), url(" + post.img + ")", backgroundSize: "cover", backgroundPosition: "center" } : undefined}>
        {!post.img && <span className="kz-blog-glyph">◆</span>}
      </div>
      <div className="kz-post-body">
        <p className="kz-post-lead">{post.resumo}</p>
        {post.topicos.map((t) => (
          <section key={t.h2}>
            <h2 className="kz-h2 kz-post-h2">{t.h2}</h2>
            <p className="kz-post-p">{t.p}</p>
          </section>
        ))}
        <KD2 style={{ margin: "var(--space-7) 0" }} />
        <h3 className="kz-h3">{post.dicas.h3}</h3>
        <p className="kz-post-p">{post.dicas.p}</p>

        <div className="kz-post-cta">
          <h4 className="kz-h4">{post.cta}</h4>
          <div className="kz-hero-actions">
            <B2 variant="gold" iconRight="→" onClick={() => { seo2.track("cta_click", { label: post.cta, origem: "blog" }); location.hash = "#/reservas"; }}>Reservar mesa</B2>
            <B2 variant="outline" onClick={() => { location.hash = "#/menu"; }}>Ver cardápio</B2>
          </div>
        </div>
      </div>

      <div className="kz-section kz-post-related">
        <h2 className="kz-h2 kz-center">Continue lendo</h2>
        <div className="kz-related-grid">
          {related.map((p) => (
            <a key={p.slug} href={"#/blog/" + p.slug} className="kz-related-card">
              <span className="kz-blog-cat">{p.categoria}</span>
              <h3 className="kz-h3">{p.titulo}</h3>
              <span className="kz-blog-readmore">Ler →</span>
            </a>
          ))}
        </div>
      </div>
    </article>
  );
}

/* ============ ADMIN ============ */
function AdminPage() {
  const [authed, setAuthed] = React.useState(false);
  const [user, setUser] = React.useState("");
  const [pass, setPass] = React.useState("");
  const [err, setErr] = React.useState(false);

  React.useEffect(() => { seo2.track("admin_access", { autenticado: false, acao: "tela_login" }); }, []);

  const login = (e) => {
    e.preventDefault();
    if (user.trim() && pass.trim()) {
      setAuthed(true); setErr(false);
      seo2.track("admin_access", { autenticado: true, usuario: user });
    } else { setErr(true); }
  };

  if (!authed) {
    return (
      <div className="kz-admin-login-wrap">
        <Cd2 pattern className="kz-admin-login">
          <span className="kz-admin-lock">🔒</span>
          <h1 className="kz-h2" style={{ marginTop: 0 }}>Área Restrita</h1>
          <p className="kz-body">Acesso somente para a equipe ZEN SUSHI. Esta página é <code>noindex, nofollow</code>.</p>
          <form className="kz-form" onSubmit={login} noValidate>
            <div className="kz-field">
              <label htmlFor="a-user">Usuário</label>
              <input id="a-user" value={user} onChange={(e) => setUser(e.target.value)} placeholder="admin" />
            </div>
            <div className="kz-field">
              <label htmlFor="a-pass">Senha</label>
              <input id="a-pass" type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder="••••••••" />
            </div>
            {err && <span className="kz-err">Preencha usuário e senha (demo: qualquer valor).</span>}
            <B2 variant="gold" size="lg" fullWidth type="submit" iconRight="→">Entrar no painel</B2>
          </form>
          <p className="kz-admin-redirect">Sem autenticação, o acesso é redirecionado para esta tela de login.</p>
        </Cd2>
      </div>
    );
  }

  return (
    <div className="kz-section kz-admin">
      <div className="kz-admin-head">
        <div>
          <Ey2 rule="left">Painel privado · noindex</Ey2>
          <h1 className="kz-h2" style={{ margin: 0 }}>Painel</h1>
        </div>
        <B2 variant="ghost" onClick={() => setAuthed(false)}>Sair</B2>
      </div>

      <div className="kz-admin-grid">
        <Cd2>
          <h2 className="kz-h3">Edição de Conteúdo</h2>
          <p className="kz-body">Atualize textos das páginas, descrições de pratos e metadados de SEO.</p>
          <ul className="kz-admin-list">
            <li>Home · H1 e Missão <span className="kz-admin-pill">Publicado</span></li>
            <li>Cardápio · 45 itens <span className="kz-admin-pill">Publicado</span></li>
            <li>Blog · 5 artigos <span className="kz-admin-pill">Publicado</span></li>
          </ul>
        </Cd2>
        <Cd2>
          <h3 className="kz-h3">Upload de Mídia</h3>
          <p className="kz-body">Envie fotos dos pratos e capas dos artigos (otimizadas com alt-text automático).</p>
          <div className="kz-admin-drop">Arraste imagens aqui ou clique para enviar</div>
        </Cd2>
        <Cd2>
          <h4 className="kz-h4" style={{ marginTop: 0 }}>Gerenciamento de Links</h4>
          <p className="kz-body">Configure links de delivery, redes sociais e WhatsApp.</p>
          <ul className="kz-admin-links">
            {RST.delivery.map((d) => (<li key={d.id}><span>{d.nome}</span><code>{d.url}</code></li>))}
            <li><span>WhatsApp</span><code>wa.me/{RST.whatsapp}</code></li>
          </ul>
        </Cd2>
      </div>
    </div>
  );
}

Object.assign(window, { LocalizacaoPage, BlogPage, BlogPostPage, AdminPage });

/* ===================== router + mount ===================== */
/* ZEN SUSHI — router + app shell. */
const { useState: uS, useEffect: uE } = React;
const SEOx = window.KZ_SEO;
const BLOGX = window.KZ_DATA.BLOG;

function parseRoute() {
  let h = location.hash.replace(/^#/, "");
  if (!h || h === "/") return { name: "home" };
  const parts = h.split("/").filter(Boolean); // e.g. ["blog","slug"]
  const top = parts[0];
  if (top === "blog" && parts[1]) {
    const post = BLOGX.find((p) => p.slug === parts[1]);
    return post ? { name: "blogPost", post } : { name: "blog" };
  }
  const known = { menu: "menu", reservas: "reservas", delivery: "delivery", localizacao: "localizacao", blog: "blog", admin: "admin" };
  return { name: known[top] || "home" };
}

function App() {
  const [route, setRoute] = uS(parseRoute());
  const [audOpen, setAudOpen] = uS(false);
  const [audTab, setAudTab] = uS("audit");

  uE(() => {
    const onHash = () => {
      const r = parseRoute();
      setRoute(r);
      if (window.lenis) window.lenis.scrollTo(0, { immediate: true });
      else window.scrollTo({ top: 0, behavior: "auto" });
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  // apply SEO head for the active route
  uE(() => {
    const meta = route.name === "blogPost"
      ? SEOx.ROUTES.blogPost(route.post)
      : (SEOx.ROUTES[route.name] || SEOx.ROUTES.home)();
    SEOx.applyHead(meta);
    // A altura da página muda a cada rota → remede o limite da Lenis.
    if (window.lenis) {
      requestAnimationFrame(() => window.lenis.resize());
      setTimeout(() => window.lenis && window.lenis.resize(), 350);
    }
  }, [route]);

  let Page = null;
  switch (route.name) {
    case "home": Page = <HomePage />; break;
    case "menu": Page = <MenuPage />; break;
    case "reservas": Page = <ReservasPage />; break;
    case "delivery": Page = <DeliveryPage />; break;
    case "localizacao": Page = <LocalizacaoPage />; break;
    case "blog": Page = <BlogPage />; break;
    case "blogPost": Page = <BlogPostPage post={route.post} />; break;
    case "admin": Page = <AdminPage />; break;
    default: Page = <HomePage />;
  }

  const isAdmin = route.name === "admin";

  return (
    <React.Fragment>
      <Nav route={route.name} />
      <main id="page-root">{Page}</main>
      {!isAdmin && <Footer />}
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
